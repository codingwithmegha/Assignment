package controlSystem;

public class SwitchEg {
	public static void main(String[] args) {
		int day=2; //declaring a variable for switch
		switch(day) //switch expression
		{
		case 1:
			System.out.println("monday");
		break;
		case 2:
			System.out.println("tuesday");
		break;
		case 3:
			System.out.println("wednesday");
		break;
		case 4:
			System.out.println("thursday");
		break;
		case 5:
			System.out.println("friday");
		break;
		case 6:
			System.out.println("saturady");
			break;
		case 7:
			System.out.println("sunday");
		break;
		
		default:System.out.println("invalid day");
		}
	}

}
