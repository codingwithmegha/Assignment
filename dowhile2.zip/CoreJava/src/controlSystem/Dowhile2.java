package controlSystem;

public class Dowhile2 {
	public static void main(String[] args) {
		
	int i=1;
	System.out.println("First 10 odd number");
	do {
		System.out.println(i);
		i=i+2;
	}while(i<=20);

	}

}
